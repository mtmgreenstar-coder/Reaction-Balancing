# Reaction Balancer V4.0 — Android

Offline Android WebView wrapper for the supplied `Reaction_Balancer_V4.0.html`.

## Build APK with GitHub Actions
1. Create a new GitHub repository.
2. Upload the contents of this ZIP (the files inside the folder, not the outer folder) to the repository's `main` branch.
3. Open **Actions** → **Build Reaction Balancer APK** → **Run workflow**.
4. When complete, open the workflow run and download the artifact named **Reaction-Balancer-V4.0-APK**.
5. Extract the artifact ZIP; install `app-debug.apk` on Android.

App ID: `com.mtm.reactionbalancer`  
Version: `4.0`  
The HTML and launcher icon are bundled locally; no internet permission is requested.
